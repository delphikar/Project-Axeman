//var extensionId = "iocibcglikkcbjcdkenhnfngokknheen";
var extensionId = chrome.i18n.getMessage("@@extension_id");
